﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DGVPrinterHelper;
using MySql.Data.MySqlClient;

namespace SalesInventorySystem
{
    public partial class AdminFrm : Form
    {
        public AdminFrm()
        {
            InitializeComponent();
        }
        MySqlConnection con = new MySqlConnection("Server=localhost;uid=root;pwd=1234;database=inventorydb;port=3306");
        MySqlCommand command;
        MySqlDataReader reader;


        public void executeQuery1(String query1)
        {
            try
            {
                con.Open();
                command = new MySqlCommand(query1, con);

                reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dataGridView1.DataSource = dt;
                }
                else
                {
                    label10.Visible = true;
                    label10.ForeColor = Color.Red;
                    label10.Text = "Invalid/Empty field!";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public void executeQuery2(String query2)
        {
            try
            {
                con.Open();
                command = new MySqlCommand(query2, con);

                if (command.ExecuteNonQuery() == 1)
                {

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                con.Close();
            }
        }
        public void executeQuery3(String query3)
        {
            try
            {
                con.Open();
                command = new MySqlCommand(query3, con);

                reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dataGridView2.DataSource = dt;
                }
                else
                {
                    label13.Visible = true;
                    label13.ForeColor = Color.Red;
                    label13.Text = "Invalid/Empty field!";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        public void executeQuery4(String query4)
        {
            try
            {
                con.Open();
                command = new MySqlCommand(query4, con);

                reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    dataGridView6.DataSource = dt;
                }
                else
                {
                    label34.Visible = true;
                    label34.ForeColor = Color.Red;
                    label34.Text = "Invalid/Empty field!";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();

            }
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void AdminFrm_Load(object sender, EventArgs e)
        {
            timer1.Start();
            /*  System.Windows.Forms.ToolTip tt = new System.Windows.Forms.ToolTip();
              tt.SetToolTip(this.pictureBox15, "ITEM'S LIST");
              tt.SetToolTip(this.pictureBox10, "STOCK'S");
              tt.SetToolTip(this.pictureBox12, "SALE'S");
              tt.SetToolTip(this.pictureBox24, "ACCOUNT'S LIST");
              tt.SetToolTip(this.pictureBox23, "HELP?");
              tt.SetToolTip(this.pictureBox25, "ACTIVITY LOG");
              tt.SetToolTip(this.pictureBox9, "BACKUP & RESTORE");
              tt.SetToolTip(this.pictureBox11, "ARCHIEVE");
              tt.SetToolTip(this.pictureBox7, "CHANGE USER");
              tt.SetToolTip(this.pictureBox6, "LOG-OUT");*/
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void home_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }


        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void Stocks_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT itemcode as 'Item Code', itemname as 'Item Name', category as 'Category', description as 'Description', price as 'Price', stocks as 'Stocks' FROM inventorydb.items where stocks > 20 ", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView2.DataSource = dt;
                MySqlDataAdapter da1 = new MySqlDataAdapter("SELECT itemcode as 'Item Code', itemname as 'Item Name', category as 'Category', description as 'Description', price as 'Price', stocks as 'Stocks' FROM inventorydb.items where stocks < 21", con);
                DataTable dt1 = new DataTable();
                da1.Fill(dt1);
                dataGridView12.DataSource = dt1;
                con.Close();
            }
            catch { }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        public void Item()
        {
            string query1 = "SELECT itemcode as 'Item Code', itemname as 'Item Name', category as 'Category', description as 'Description', vat as 'VAT', price as 'Price' FROM inventorydb.items";
            executeQuery1(query1);
            int rowCount = dataGridView1.Rows.Count;
            label9.Text = rowCount.ToString();
        }


        private void Item_Click(object sender, EventArgs e)
        {
            Item();
        }

        private void textBox7_TextChanged_1(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT itemcode as 'Item Code', itemname as 'Item Name', category as 'Category', description as 'Description', vat as 'VAT', price as 'Price' FROM inventorydb.items where itemname LIKE  '%" + textBox1.Text + "%'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT itemcode as 'Item Code', itemname as 'Item Name', category as 'Category', description as 'Description', price as 'Price', stocks as 'Stocks' FROM inventorydb.items where itemname LIKE  '%" + textBox8.Text + "%'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView2.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView2_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = this.dataGridView2.Rows[e.RowIndex];
                textBox9.Text = row.Cells["Item Code"].Value.ToString();
                textBox10.Text = row.Cells["Item Name"].Value.ToString();
                textBox11.Text = row.Cells["Category"].Value.ToString();
                textBox12.Text = row.Cells["Description"].Value.ToString();
                textBox13.Text = row.Cells["Price"].Value.ToString();
                textBox14.Text = row.Cells["Stocks"].Value.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Item Code"].Value.ToString();
                textBox2.Text = row.Cells["Item Name"].Value.ToString();
                textBox3.Text = row.Cells["Category"].Value.ToString();
                textBox4.Text = row.Cells["Description"].Value.ToString();
                textBox5.Text = row.Cells["VAT"].Value.ToString();
                textBox6.Text = row.Cells["Price"].Value.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
            textBox6.Enabled = true;
            button1.Enabled = true;
            button4.Enabled = true;
            button3.Enabled = true;
            button2.Enabled = false;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(textBox1.Text) || String.IsNullOrWhiteSpace(textBox2.Text) || String.IsNullOrWhiteSpace(textBox3.Text) || String.IsNullOrWhiteSpace(textBox4.Text) || String.IsNullOrWhiteSpace(textBox5.Text) || String.IsNullOrWhiteSpace(textBox6.Text))
            {
                label10.Visible = true;
                label10.ForeColor = Color.Red;
                label10.Text = "Unable to update. Some of the field is empty";

            }
            else
            {

                string query2 = string.Format("UPDATE inventorydb.items SET itemname = '" + textBox2.Text + "' Where itemcode = '" + textBox1.Text + "';" +
               "UPDATE inventorydb.items SET category = '" + textBox3.Text + "' Where itemcode = '" + textBox1.Text + "';" +
               "UPDATE inventorydb.items SET description = '" + textBox4.Text + "' Where itemcode = '" + textBox1.Text + "';" +
               "UPDATE inventorydb.items SET vat = '" + textBox5.Text + "' Where itemcode = '" + textBox1.Text + "';" +
               "UPDATE inventorydb.items SET price = '" + textBox6.Text + "' Where itemcode = '" + textBox1.Text + "';");
                executeQuery2(query2);
                string time = DateTime.Now.ToString("hh:mm:ss tt");
                string date = DateTime.Now.ToShortDateString();
                string query3 = string.Format("insert into inventorydb.accountslog(id, username, date, action) values(Default, '" + label22.Text + "','" + date + " " + time + "','" + label22.Text + " updated " + textBox3.Text + "');");
                executeQuery2(query3);

                Item();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox1.Enabled = false;
                textBox2.Enabled = false;
                textBox3.Enabled = false;
                textBox4.Enabled = false;
                textBox5.Enabled = false;
                textBox6.Enabled = false;
                button2.Enabled = true;
                button3.Enabled = false;
                button1.Enabled = false;
                button4.Enabled = false;
                label10.Visible = true;
                label10.ForeColor = Color.Green;
                label10.Text = "Updated!";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
            textBox6.Enabled = false;
            button1.Enabled = false;
            button4.Enabled = false;
            button3.Enabled = false;
            button2.Enabled = true;
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(textBox1.Text) || String.IsNullOrWhiteSpace(textBox2.Text) || String.IsNullOrWhiteSpace(textBox3.Text) || String.IsNullOrWhiteSpace(textBox4.Text) || String.IsNullOrWhiteSpace(textBox5.Text) || String.IsNullOrWhiteSpace(textBox6.Text))
            {
                label10.Visible = true;
                label10.ForeColor = Color.Red;
                label10.Text = "Unable to delete. Some of the field is empty";

            }
            else
            {

                string query2 = "delete from inventorydb.items where itemcode ='" + textBox1.Text + "';";
                executeQuery2(query2);
                string time = DateTime.Now.ToString("hh:mm:ss tt");
                string date = DateTime.Now.ToShortDateString();
                string query3 = string.Format("insert into inventorydb.accountslog(id, username, date, action) values(Default, '" + label22.Text + "','" + date + " " + time + "','" + label22.Text + " deleted " + textBox3.Text + "');");
                executeQuery2(query3);

                Item();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox1.Enabled = false;
                textBox2.Enabled = false;
                textBox3.Enabled = false;
                textBox4.Enabled = false;
                textBox5.Enabled = false;
                textBox6.Enabled = false;
                button2.Enabled = true;
                button3.Enabled = false;
                button1.Enabled = false;
                button4.Enabled = false;
                label10.Visible = true;
                label10.ForeColor = Color.Green;
                label10.Text = "Deleted!";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try {
                if (String.IsNullOrWhiteSpace(textBox9.Text) || String.IsNullOrWhiteSpace(textBox10.Text) || String.IsNullOrWhiteSpace(textBox11.Text) || String.IsNullOrWhiteSpace(textBox12.Text) || String.IsNullOrWhiteSpace(textBox13.Text) || String.IsNullOrWhiteSpace(textBox14.Text))
                {
                    label13.Visible = true;
                    label13.ForeColor = Color.Red;
                    label13.Text = "Unable to update. Some of the field is empty";

                }
                else
                {
                    int add = Convert.ToInt32(textBox30.Text);
                    int current = Convert.ToInt32(textBox14.Text);
                    int total = current + add;
                    string query2 = string.Format("UPDATE inventorydb.items SET stocks = '" + total + "' Where itemcode = '" + textBox9.Text + "';");
                    executeQuery2(query2);
                    string time = DateTime.Now.ToString("hh:mm:ss tt");
                    string date = DateTime.Now.ToShortDateString();
                    string query3 = string.Format("insert into inventorydb.accountslog(id, username, date, action) values(Default, '" + label22.Text + "','" + date + " " + time + "','" + label22.Text + " updated " + textBox3.Text + "');");
                    executeQuery2(query3);
                    con.Open();
                    MySqlDataAdapter da = new MySqlDataAdapter("SELECT itemcode as 'Item Code', itemname as 'Item Name', category as 'Category', description as 'Description', price as 'Price', stocks as 'Stocks' FROM inventorydb.items where stocks > 20 ", con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView2.DataSource = dt;
                    MySqlDataAdapter da1 = new MySqlDataAdapter("SELECT itemcode as 'Item Code', itemname as 'Item Name', category as 'Category', description as 'Description', price as 'Price', stocks as 'Stocks' FROM inventorydb.items where stocks < 21", con);
                    DataTable dt1 = new DataTable();
                    da1.Fill(dt1);
                    dataGridView12.DataSource = dt1;
                    con.Close();

                    textBox9.Text = "";
                    textBox10.Text = "";
                    textBox11.Text = "";
                    textBox12.Text = "";
                    textBox13.Text = "";
                    textBox14.Text = "";
                    textBox30.Text = "";
                    textBox9.Enabled = false;
                    textBox10.Enabled = false;
                    textBox11.Enabled = false;
                    textBox12.Enabled = false;
                    textBox13.Enabled = false;
                    textBox14.Enabled = false;
                    label13.Visible = true;
                    label13.ForeColor = Color.Green;
                    label13.Text = "Added Successfully!";
                }

            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

            try
            {

                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT itemcode as 'Item Code', item as 'Item', date as 'Date', oras as 'Time', quantity as 'Quantity', price as 'Price', total as 'Total' FROM inventorydb.sales where date like '%" + dateTimePicker1.Value.ToString("MMMM/dd/yyyy") + "%'", con);
                DataSet ds = new DataSet();
                da.Fill(ds, "sales");
                dataGridView3.DataSource = ds.Tables["sales"];
                con.Close();
                //Total Amount

                int A = 0;
                int B = 0;
                int C = 0;
                int D = 0;
                for (A = 0; A < dataGridView3.Rows.Count; ++A)
                {

                    B += Convert.ToInt32(dataGridView3.Rows[A].Cells[6].Value);

                }

                textBox16.Text = B.ToString();

                //Total Items

                for (C = 0; C < dataGridView3.Rows.Count; ++C)
                {
                    D += Convert.ToInt32(dataGridView3.Rows[C].Cells[4].Value);
                }
                textBox15.Text = D.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            try
            {
                comboBox4.Text = DateTime.Now.ToString("MMMM");
                comboBox1.Text = DateTime.Now.ToString("yyyy");
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT itemcode as 'Item Code', item as 'Item', date as 'Date', oras as 'Time', quantity as 'Quantity', price as 'Price', total as 'Total' FROM inventorydb.sales where date like '" + comboBox4.Text + "%' and '" + comboBox1.Text + "%'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView4.DataSource = dt;
                con.Close();
                //Total Amount

                int A = 0;
                int B = 0;
                int C = 0;
                int D = 0;
                for (A = 0; A < dataGridView4.Rows.Count; ++A)
                {

                    B += Convert.ToInt32(dataGridView4.Rows[A].Cells[6].Value);

                }

                textBox17.Text = B.ToString();

                //Total Items

                for (C = 0; C < dataGridView4.Rows.Count; ++C)
                {
                    D += Convert.ToInt32(dataGridView4.Rows[C].Cells[4].Value);
                }
                textBox18.Text = D.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {
            try
            {
                comboBox2.Text = DateTime.Now.ToString("yyyy");
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT itemcode as 'Item Code', item as 'Item', date as 'Date', oras as 'Time', quantity as 'Quantity', price as 'Price', total as 'Total' FROM inventorydb.sales where date like  '%" + comboBox2.Text + "%'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView5.DataSource = dt;
                con.Close();
                //Total Amount

                int A = 0;
                int B = 0;
                int C = 0;
                int D = 0;
                for (A = 0; A < dataGridView5.Rows.Count; ++A)
                {

                    B += Convert.ToInt32(dataGridView5.Rows[A].Cells[6].Value);

                }

                textBox19.Text = B.ToString();

                //Total Items

                for (C = 0; C < dataGridView5.Rows.Count; ++C)
                {
                    D += Convert.ToInt32(dataGridView5.Rows[C].Cells[4].Value);
                }
                textBox20.Text = D.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox21_TextChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT id as 'User ID', username as 'Username', password as 'Password', firstname as 'Firstname', lastname as 'Lastname', type as 'Type', contact as 'Contact', age as 'Age' FROM users where username LIKE  '%" + textBox21.Text + "%'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView6.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void account()
        {
            try
            {
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT id as 'User ID', username as 'Username', password as 'Password', firstname as 'Firstname', lastname as 'Lastname', type as 'Type', contact as 'Contact', age as 'Age' FROM users", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView6.DataSource = dt;
                con.Close();
                int rowCount = dataGridView6.Rows.Count;
                label32.Text = rowCount.ToString();
                textBox21.BackColor = Color.DarkGray;
                pictureBox5.BackColor = Color.DarkGray;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void Accounts_Click(object sender, EventArgs e)
        {
            account();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView6_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = this.dataGridView6.Rows[e.RowIndex];
                textBox22.Text = row.Cells["User ID"].Value.ToString();
                textBox23.Text = row.Cells["Firstname"].Value.ToString();
                textBox24.Text = row.Cells["Lastname"].Value.ToString();
                textBox25.Text = row.Cells["Username"].Value.ToString();
                textBox26.Text = row.Cells["Password"].Value.ToString();
                textBox27.Text = row.Cells["Type"].Value.ToString();
                textBox28.Text = row.Cells["Contact"].Value.ToString();
                textBox29.Text = row.Cells["Age"].Value.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox22.Enabled = true;
            textBox23.Enabled = true;
            textBox24.Enabled = true;
            textBox25.Enabled = true;
            textBox26.Enabled = true;
            textBox27.Enabled = true;
            textBox28.Enabled = true;
            textBox29.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button9.Enabled = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox22.Enabled = false;
            textBox23.Enabled = false;
            textBox24.Enabled = false;
            textBox25.Enabled = false;
            textBox26.Enabled = false;
            textBox27.Enabled = false;
            textBox28.Enabled = false;
            textBox29.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button9.Enabled = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(textBox22.Text) || String.IsNullOrWhiteSpace(textBox24.Text) || String.IsNullOrWhiteSpace(textBox25.Text) || String.IsNullOrWhiteSpace(textBox26.Text) || String.IsNullOrWhiteSpace(textBox27.Text) || String.IsNullOrWhiteSpace(textBox28.Text) || String.IsNullOrWhiteSpace(textBox29.Text))
            {
                label34.Visible = true;
                label34.ForeColor = Color.Red;
                label34.Text = "Unable to update. Some of the field is empty";

            }
            else
            {

                string query4 = string.Format("UPDATE inventorydb.users SET username = '" + textBox25.Text + "' Where id = '" + textBox22.Text + "';" +
               "UPDATE inventorydb.users SET password = '" + textBox26.Text + "' Where id = '" + textBox22.Text + "';" +
               "UPDATE inventorydb.users SET firstname = '" + textBox23.Text + "' Where id = '" + textBox22.Text + "';" +
               "UPDATE inventorydb.users SET lastname= '" + textBox24.Text + "' Where id = '" + textBox22.Text + "';" +
               "UPDATE inventorydb.users SET type= '" + textBox27.Text + "' Where id = '" + textBox22.Text + "';" +
               "UPDATE inventorydb.users SET contact= '" + textBox28.Text + "' Where id = '" + textBox22.Text + "';" +
               "UPDATE inventorydb.users SET age = '" + textBox29.Text + "' Where id = '" + textBox22.Text + "';");
                executeQuery4(query4);
                string time = DateTime.Now.ToString("hh:mm:ss tt");
                string date = DateTime.Now.ToShortDateString();
                string query3 = string.Format("insert into inventorydb.accountslog(id, username, date, action) values(Default, '" + label22.Text + "','" + date + " " + time + "','" + label22.Text + " updated " + textBox25.Text + "');");
                executeQuery2(query3);

                account();
                textBox22.Text = "";
                textBox23.Text = "";
                textBox24.Text = "";
                textBox25.Text = "";
                textBox26.Text = "";
                textBox27.Text = "";
                textBox28.Text = "";
                textBox29.Text = "";
                textBox22.Enabled = false;
                textBox23.Enabled = false;
                textBox24.Enabled = false;
                textBox25.Enabled = false;
                textBox26.Enabled = false;
                textBox27.Enabled = false;
                textBox28.Enabled = false;
                textBox29.Enabled = false;
                button9.Enabled = true;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                label34.Visible = true;
                label34.ForeColor = Color.Green;
                label34.Text = "Updated!";
            }
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(textBox22.Text) || String.IsNullOrWhiteSpace(textBox24.Text) || String.IsNullOrWhiteSpace(textBox25.Text) || String.IsNullOrWhiteSpace(textBox26.Text) || String.IsNullOrWhiteSpace(textBox27.Text) || String.IsNullOrWhiteSpace(textBox28.Text) || String.IsNullOrWhiteSpace(textBox29.Text))
            {
                label34.Visible = true;
                label34.ForeColor = Color.Red;
                label34.Text = "Unable to update. Some of the field is empty";

            }
            else
            {

                string query2 = "delete from inventorydb.users where id ='" + textBox22.Text + "';";
                executeQuery4(query2);
                string time = DateTime.Now.ToString("hh:mm:ss tt");
                string date = DateTime.Now.ToShortDateString();
                string query3 = string.Format("insert into inventorydb.accountslog(id, username, date, action) values(Default, '" + label22.Text + "','" + date + " " + time + "','" + label22.Text + " deleted! " + textBox25.Text + "');");
                executeQuery2(query3);

                account();
                textBox22.Text = "";
                textBox23.Text = "";
                textBox24.Text = "";
                textBox25.Text = "";
                textBox26.Text = "";
                textBox27.Text = "";
                textBox28.Text = "";
                textBox29.Text = "";
                textBox22.Enabled = false;
                textBox23.Enabled = false;
                textBox24.Enabled = false;
                textBox25.Enabled = false;
                textBox26.Enabled = false;
                textBox27.Enabled = false;
                textBox28.Enabled = false;
                textBox29.Enabled = false;
                button9.Enabled = true;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                label34.Visible = true;
                label34.ForeColor = Color.Green;
                label34.Text = "Deleted!";
            }
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click_1(object sender, EventArgs e)
        {
            tabControl2.SelectTab("Items");

        }

        private void pictureBox24_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab("Accounts");

        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab("Sales");

        }

        private void pictureBox10_Click_1(object sender, EventArgs e)
        {
            tabControl2.SelectTab("Stocks");


        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void Logs_Click(object sender, EventArgs e)
        {

        }

        private void loginhis_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM inventorydb.loginhistory", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "loginhistory");
            dataGridView10.DataSource = ds.Tables["loginhistory"];
            con.Close();
        }

        private void pictureBox25_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab("Logs");
        }

        private void itemslog_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM inventorydb.itemlog", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "itemlog");
            dataGridView7.DataSource = ds.Tables["itemlog"];
            con.Close();
        }

        private void stockslog_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM inventorydb.stocklog", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "stocklogitemlog");
            dataGridView8.DataSource = ds.Tables["stocklog"];
            con.Close();
        }

        private void dataGridView7_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void accountslog_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM inventorydb.accountslog", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "accountslog");
            dataGridView9.DataSource = ds.Tables["accountslog"];
            con.Close();
        }

        private void textBox21_Click(object sender, EventArgs e)
        {
            textBox21.BackColor = Color.WhiteSmoke;
            pictureBox5.BackColor = Color.WhiteSmoke;

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox7_Click_1(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to Change the User? ", "", MessageBoxButtons.OK);
            if (dialogResult == DialogResult.OK)
            {
                string time = DateTime.Now.ToString("hh:mm:ss tt");
                string date = DateTime.Now.ToShortDateString();
                string query2 = string.Format("UPDATE inventorydb.loginhistory SET timeout = '" + date + " " + time + "' Where id = '" + label1.Text + "';");
                executeQuery2(query2);
                Loginfrm log = new Loginfrm();
                this.Close();
                log.Show();
            }
        }

        private void pictureBox6_Click_1(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to LogOut? ", "", MessageBoxButtons.OK);
            if (dialogResult == DialogResult.OK)
            {
                string time = DateTime.Now.ToString("hh:mm:ss tt");
                string date = DateTime.Now.ToShortDateString();
                string query2 = string.Format("UPDATE inventorydb.loginhistory SET timeout = '" + date + " " + time + "' Where id = '" + label1.Text + "';");
                executeQuery2(query2);
                Application.Exit();

            }
        }

        private void panel1_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab("Home");
        }

        private void label16_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab("Home");
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab("Home");
        }

        private void pictureBox8_MouseHover(object sender, EventArgs e)
        {

            panel3.BackColor = Color.CadetBlue;
        }

        private void pictureBox10_MouseHover(object sender, EventArgs e)
        {
            pictureBox10.BackColor = Color.CadetBlue;
            panel4.BackColor = Color.CadetBlue;
        }

        private void pictureBox12_MouseHover(object sender, EventArgs e)
        {
            pictureBox12.BackColor = Color.CadetBlue;
            panel5.BackColor = Color.CadetBlue;
        }

        private void pictureBox24_MouseHover(object sender, EventArgs e)
        {
            pictureBox24.BackColor = Color.CadetBlue;
            panel6.BackColor = Color.CadetBlue;
        }

        private void pictureBox25_MouseHover(object sender, EventArgs e)
        {
            pictureBox25.BackColor = Color.CadetBlue;
            panel7.BackColor = Color.CadetBlue;
        }

        private void pictureBox23_MouseHover(object sender, EventArgs e)
        {
            pictureBox23.BackColor = Color.CadetBlue;
            panel8.BackColor = Color.CadetBlue;
        }

        private void pictureBox11_MouseHover(object sender, EventArgs e)
        {
            pictureBox11.BackColor = Color.CadetBlue;
            panel9.BackColor = Color.CadetBlue;
        }

        private void pictureBox9_MouseHover(object sender, EventArgs e)
        {
            pictureBox9.BackColor = Color.CadetBlue;
            panel10.BackColor = Color.CadetBlue;
        }

        private void pictureBox7_MouseHover(object sender, EventArgs e)
        {
            pictureBox7.BackColor = Color.CadetBlue;
            panel11.BackColor = Color.CadetBlue;
        }

        private void pictureBox6_MouseHover(object sender, EventArgs e)
        {
            pictureBox6.BackColor = Color.CadetBlue;
            panel12.BackColor = Color.CadetBlue;
        }

        private void pictureBox6_MouseLeave(object sender, EventArgs e)
        {
            panel12.BackColor = Color.FromArgb(34, 36, 45);
            pictureBox6.BackColor = Color.FromArgb(34, 36, 45);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox7_MouseLeave(object sender, EventArgs e)
        {
            panel11.BackColor = Color.FromArgb(34, 36, 45);
            pictureBox7.BackColor = Color.FromArgb(34, 36, 45);
        }

        private void pictureBox9_MouseLeave(object sender, EventArgs e)
        {
            panel10.BackColor = Color.FromArgb(34, 36, 45);
            pictureBox9.BackColor = Color.FromArgb(34, 36, 45);

        }

        private void pictureBox11_MouseLeave(object sender, EventArgs e)
        {
            panel9.BackColor = Color.FromArgb(34, 36, 45);
            pictureBox11.BackColor = Color.FromArgb(34, 36, 45);

        }

        private void pictureBox23_MouseLeave(object sender, EventArgs e)
        {
            panel8.BackColor = Color.FromArgb(34, 36, 45);
            pictureBox23.BackColor = Color.FromArgb(34, 36, 45);

        }

        private void pictureBox25_MouseLeave(object sender, EventArgs e)
        {
            panel7.BackColor = Color.FromArgb(34, 36, 45);
            pictureBox25.BackColor = Color.FromArgb(34, 36, 45);

        }

        private void pictureBox24_MouseLeave(object sender, EventArgs e)
        {
            panel6.BackColor = Color.FromArgb(34, 36, 45);
            pictureBox24.BackColor = Color.FromArgb(34, 36, 45);

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox12_MouseLeave(object sender, EventArgs e)
        {
            panel5.BackColor = Color.FromArgb(34, 36, 45);
            pictureBox12.BackColor = Color.FromArgb(34, 36, 45);

        }

        private void pictureBox10_MouseLeave(object sender, EventArgs e)
        {
            panel4.BackColor = Color.FromArgb(34, 36, 45);

            pictureBox10.BackColor = Color.FromArgb(34, 36, 45);

        }



        private void timer1_Tick(object sender, EventArgs e)
        {
            label45.Text = DateTime.Now.ToShortDateString();
            label46.Text = DateTime.Now.ToShortTimeString();
        }

        private void pictureBox23_Click(object sender, EventArgs e)
        {

        }

        private void panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Archieve_Click(object sender, EventArgs e)
        {
            try {
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT itemcode as 'Item Code', item as 'Item', date as 'Date', oras as 'Time', quantity as 'Quantity', price as 'Price', total as 'Total' FROM inventorydb.sales", con);
                DataSet ds = new DataSet();
                da.Fill(ds, "sales");
                dataGridView11.DataSource = ds.Tables["sales"];
                con.Close();
                //Total Amount

                int A = 0;
                int B = 0;
                int C = 0;
                int D = 0;
                for (A = 0; A < dataGridView11.Rows.Count; ++A)
                {

                    B += Convert.ToInt32(dataGridView11.Rows[A].Cells[6].Value);

                }

                textBox32.Text = B.ToString();

                //Total Items

                for (C = 0; C < dataGridView11.Rows.Count; ++C)
                {
                    D += Convert.ToInt32(dataGridView11.Rows[C].Cells[4].Value);
                }
                textBox33.Text = D.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void textBox31_TextChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT itemcode as 'Item Code', item as 'Item', date as 'Date', oras as 'Time', quantity as 'Quantity', price as 'Price', total as 'Total' FROM inventorydb.sales where invoiceno LIKE  '%" + textBox1.Text + "%'", con);
                DataSet ds = new DataSet();
                da.Fill(ds, "sales");
                dataGridView11.DataSource = ds.Tables["sales"];
                con.Close();
                //Total Amount

                int A = 0;
                int B = 0;
                int C = 0;
                int D = 0;
                for (A = 0; A < dataGridView11.Rows.Count; ++A)
                {

                    B += Convert.ToInt32(dataGridView11.Rows[A].Cells[6].Value);

                }

                textBox32.Text = B.ToString();

                //Total Items

                for (C = 0; C < dataGridView11.Rows.Count; ++C)
                {
                    D += Convert.ToInt32(dataGridView11.Rows[C].Cells[4].Value);
                }
                textBox33.Text = D.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView12_CellBorderStyleChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView12_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                DataGridViewRow row = this.dataGridView12.Rows[e.RowIndex];
                textBox9.Text = row.Cells["Item Code"].Value.ToString();
                textBox10.Text = row.Cells["Item Name"].Value.ToString();
                textBox11.Text = row.Cells["Category"].Value.ToString();
                textBox12.Text = row.Cells["Description"].Value.ToString();
                textBox13.Text = row.Cells["Price"].Value.ToString();
                textBox14.Text = row.Cells["Stocks"].Value.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab("Archieve");
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            panel14.Visible = true;
        }

        private void pictureBox3_Click_1(object sender, EventArgs e)
        {
            panel13.Visible = true;
        }

        private void button15_Click(object sender, EventArgs e)
        {

            try
            {
                string query1 = string.Format("insert into inventorydb.items(itemcode,itemname,description,category, stocks, subtotal, vat, price) values('" + textBox37.Text + "','" + textBox42.Text + "','" + textBox43.Text + "','" + comboBox5.Text + "','" + textBox46.Text + "','" + textBox44.Text + "','" + textBox45.Text + "','" + textBox47.Text + "');");


                if (String.IsNullOrEmpty(textBox37.Text) || String.IsNullOrEmpty(textBox42.Text) || String.IsNullOrEmpty(textBox43.Text) || String.IsNullOrEmpty(textBox44.Text) || String.IsNullOrEmpty(textBox45.Text) || String.IsNullOrEmpty(textBox46.Text) || String.IsNullOrEmpty(textBox47.Text) || String.IsNullOrEmpty(comboBox5.Text))
                {

                    label67.Visible = true;
                    label67.ForeColor = Color.Red;
                    label67.Text = "Please enter all the missing information";

                }

                else
                {
                    executeQuery2(query1);

                    string time = DateTime.Now.ToString("hh:mm:ss tt");
                    string date = DateTime.Now.ToShortDateString();
                    string query4 = string.Format("insert into inventorydb.itemlog(id, item, sched, action) values(Default, '" + textBox42.Text + "','" + date + " " + time + "','" + label22.Text + " added " + textBox42.Text + "');");
                    executeQuery2(query4);
                    MessageBox.Show("Item's added successfully!");
                    panel14.Visible = false;
                    Item();


                }



            }
            catch (Exception)
            {
                MessageBox.Show("Error: There was a duplicate data.");
            }

        }

        private void label68_Click(object sender, EventArgs e)
        {
            panel14.Visible = false;
        }

        private void label69_Click(object sender, EventArgs e)
        {
            panel13.Visible = false;
        }

        private void button14_Click(object sender, EventArgs e)
        {

            try
            {
                string query1 = string.Format("insert into inventorydb.users(id,username,password,firstname,lastname,type,contact,age) values(Default,'" + textBox34.Text + "','" + textBox35.Text + "','" + textBox36.Text + "','" + textBox38.Text + "','" + comboBox3.Text + "','" + textBox40.Text + "','" + textBox39.Text + "');");


                if (String.IsNullOrEmpty(textBox34.Text) || String.IsNullOrEmpty(textBox35.Text) || String.IsNullOrEmpty(comboBox3.Text) || String.IsNullOrEmpty(textBox36.Text) || String.IsNullOrEmpty(textBox38.Text) || String.IsNullOrEmpty(textBox39.Text) || String.IsNullOrEmpty(textBox40.Text))
                {

                    label63.Visible = true;
                    label63.ForeColor = Color.Red;
                    label63.Text = "Please enter all the missing information";

                }

                else
                {
                    executeQuery2(query1);
                    string time = DateTime.Now.ToString("hh:mm:ss tt");
                    string date = DateTime.Now.ToShortDateString();
                    string query4 = string.Format("insert into inventorydb.accountslog(id, username, date, action) values(Default, '" + textBox34.Text + "','" + date + " " + time + "','" + label22.Text + " added " + textBox34.Text + "');");
                    executeQuery2(query4);
                    MessageBox.Show("User's info added successfully!");
                    panel13.Visible = false;
                    account();
                    textBox34.Clear();
                    textBox35.Clear();
                    textBox36.Clear();
                    textBox38.Clear();
                    textBox39.Clear();
                    textBox40.Clear();
                    comboBox3.SelectedIndex = -1;

                }

            }
            catch (Exception)
            {
                MessageBox.Show("Error: There was a duplicate data.");
            }

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label81_Click(object sender, EventArgs e)
        {

        }

        private void Home_Click_1(object sender, EventArgs e)
        {

        }



        private void button18_Click(object sender, EventArgs e)
        {
            DGVPrinter printer = new DGVPrinter();
            printer.Title = "Sale's And Inventory";
            printer.SubTitle = string.Format("Date: {0}", DateTime.Now.ToString("MMMM-dd-yyyy"));
            printer.SubTitleFormatFlags = StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
            printer.PageNumbers = true;
            printer.PageNumberInHeader = false;
            printer.PorportionalColumns = true;
            printer.HeaderCellAlignment = StringAlignment.Near;
            printer.Footer = "ITEM'S REPORT";
            printer.FooterSpacing = 15 ;
            printer.printDocument.DefaultPageSettings.Landscape = true;
            printer.PrintPreviewDataGridView(dataGridView7);
           



        }

        private void button17_Click(object sender, EventArgs e)
        {

            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                textBox41.Text = fbd.SelectedPath;


            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            /*string database = con.Database.ToString();
            try
            {
                if (textBox41.Text == string.Empty)
                {
                    MessageBox.Show("please enter backup file location");
                }
                else
                {
                    string cmd = "BACKUP DATABASE inventorydb TO DISK='" + textBox41.Text + "\\" + "Database" + "-" + DateTime.Now.ToString("yyyy-MM-dd--HH-mm-ss") + ".bak'";

                    using (MySqlCommand command = new MySqlCommand(cmd, con))
                    {
                        if (con.State != ConnectionState.Open)
                        {
                            con.Open();
                        }
                        command.ExecuteNonQuery();
                        con.Close();
                        MessageBox.Show("database backup done successefully");
                        button16.Enabled = false;
                    }
                }

            }
            catch
            {

            }*/

            string constring = "Server=localhost;uid=root;pwd=1234;database=inventorydb;port=3306";
            string file = "C:\\backup.sql";
            try
             {
            using (MySqlConnection conn = new MySqlConnection(constring))
            {
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    using (MySqlBackup mb = new MySqlBackup(cmd))
                    {
                        cmd.Connection = conn;
                        conn.Open();
                        mb.ExportToFile(file);
                        conn.Close();
                    }
                }
            }
        }
           catch (Exception ex)
            {
                MessageBox.Show("backup Linklabel error!" + ex.Message);
            }
    MessageBox.Show("Database Backedup!", "Success!");
        }
        

        private void button19_Click(object sender, EventArgs e)
        {

            string database = con.Database.ToString();
            if (con.State != ConnectionState.Open)
            {
                con.Open();
            }
            try
            {
                string sqlStmt2 = string.Format("ALTER DATABASE [" + database + "] SET SINGLE_USER WITH ROLLBACK IMMEDIATE");
                MySqlCommand bu2 = new MySqlCommand(sqlStmt2, con);
                bu2.ExecuteNonQuery();

                string sqlStmt3 = "USE MASTER RESTORE DATABASE [" + database + "] FROM DISK='" + textBox48.Text + "'WITH REPLACE;";
                MySqlCommand bu3 = new MySqlCommand(sqlStmt3, con);
                bu3.ExecuteNonQuery();

                string sqlStmt4 = string.Format("ALTER DATABASE [" + database + "] SET MULTI_USER");
                MySqlCommand bu4 = new MySqlCommand(sqlStmt4, con);
                bu4.ExecuteNonQuery();

                MessageBox.Show("database restoration done successefully");
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "SQL SERVER database backup files|*.bak";
            dlg.Title = "Database restore";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = dlg.FileName;
                button19.Enabled = true;
            }
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab("Items");
        }

        private void panel16_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel15_Paint(object sender, PaintEventArgs e)
        {


        }
    }
 }