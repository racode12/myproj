﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SalesInventorySystem
{
    public partial class CashierFrm : Form
    {
        public CashierFrm()
        {
            InitializeComponent();
        }
        MySqlConnection connection = new MySqlConnection("datasource = localhost;port = 3306 ; username = root ; password = 1234; Database=inventorydb");
        DataTable table = new DataTable();
        MySqlCommand command;

        public void executeQuery2(String query2)
        {
            try
            {
                connection.Open();
                command = new MySqlCommand(query2, connection);

                if (command.ExecuteNonQuery() == 1)
                {

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                connection.Close();
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void CashierFrm_Load(object sender, EventArgs e)
        {
            

            try
            {


                connection.Open();
                MySqlCommand mycommand = new MySqlCommand("select invoice1 from inventorydb.invoiceno Where invoiceid = 1 ", connection);
                MySqlDataReader dr;
                DataTable dt = new System.Data.DataTable();
                dr = mycommand.ExecuteReader();


                if (dr.Read())
                {
                    textBox1.Text = (dr["invoice1"].ToString());
                }

                connection.Close();
            }
            catch (Exception) { }

            table.Columns.Add("Item Code", typeof(string));
            table.Columns.Add("Item Name", typeof(string));
            table.Columns.Add("Quantity", typeof(int));
            table.Columns.Add("Vat", typeof(int));
            table.Columns.Add("Price", typeof(int));
            table.Columns.Add("Total", typeof(int));
            dataGridView1.DataSource = table;
        }

        private void panel4_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection connection1 = new MySqlConnection("datasource = localhost;port = 3306 ; username = root ; password = 1234; Database=inventorydb");
                connection1.Open();
                MySqlCommand mycommand1 = new MySqlCommand("select * from inventorydb.items Where itemcode like '" + textBox8.Text + "%'", connection1);
                MySqlDataReader dr;
                DataTable dt = new System.Data.DataTable();
                dr = mycommand1.ExecuteReader();


                if (dr.Read())
                {


                    textBox2.Text = (dr["itemcode"].ToString());
                    label13.Text = (dr["itemcode"].ToString());
                    textBox3.Text = (dr["itemname"].ToString());
                    label14.Text = (dr["itemname"].ToString());
                    textBox4.Text = (dr["description"].ToString());
                    textBox5.Text = (dr["category"].ToString());
                    textBox6.Text = (dr["vat"].ToString());
                    label18.Text = (dr["vat"].ToString());
                    textBox7.Text = (dr["price"].ToString());
                    label19.Text = (dr["stocks"].ToString());
                    textBox9.Text = "1";
                    textBox11.Text = (float.Parse(textBox7.Text) * float.Parse(textBox9.Text)).ToString();
                    textBox6.Text = (float.Parse(label18.Text) * float.Parse(textBox9.Text)).ToString();
                    
                }
                
                else
                {
                    MessageBox.Show("Please Scan Barcodes.", "Important Note", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    textBox5.Clear();
                    textBox6.Clear();
                    textBox7.Clear();
                    textBox8.Clear();
                    textBox9.Clear();
                    textBox11.Clear();
                    label19.Text = "";


                }
            }
            catch (Exception) { }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int A = 0, B = 0;
                int C = 0, D = 0;
                int X = 0, Z = 0;
                int dec = Convert.ToInt32(textBox9.Text);
                int current = Convert.ToInt32(label19.Text);
                int total = (current - dec);
                string query4;
                string time = DateTime.Now.ToString("hh:mm:ss tt");
                string date = DateTime.Now.ToString("MMMM/dd/yyyy");


                bool found = false;
                if (dataGridView1.Rows.Count > 0)
                {
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        if (Convert.ToString(row.Cells[0].Value) == textBox2.Text && Convert.ToString(row.Cells[1].Value) == textBox3.Text)
                        {

                            row.Cells[2].Value = Convert.ToString(Convert.ToInt32(textBox9.Text) + Convert.ToInt32(row.Cells[2].Value));
                            row.Cells[5].Value = Convert.ToString(Convert.ToInt32(textBox11.Text) + Convert.ToInt32(row.Cells[5].Value));
                            found = true;

                            string query2 = string.Format("UPDATE inventorydb.items SET stocks = '" + total + "' Where itemcode = '" + textBox2.Text + "';");
                            executeQuery2(query2);

                            query4 = string.Format("insert into inventorydb.sales(transactionid, invoiceno, date, oras, itemcode, item, quantity, price, total) values(Default, '" + textBox1.Text + "','" + date + "','" + time + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox9.Text + "','" + textBox7.Text + "','" + textBox11.Text + "');");
                            executeQuery2(query4);

                            textBox12.Text = dataGridView1.RowCount.ToString();


                            //Total Amount

                            for (A = 0; A < dataGridView1.Rows.Count; ++A)
                            {

                                B += Convert.ToInt32(dataGridView1.Rows[A].Cells[5].Value);

                            }

                            textBox10.Text = B.ToString();

                            //Total Items

                            for (C = 0; C < dataGridView1.Rows.Count; ++C)
                            {
                                D += Convert.ToInt32(dataGridView1.Rows[C].Cells[2].Value);
                            }
                            textBox12.Text = D.ToString();


                            //total Vat

                            for (X = 0; X < dataGridView1.Rows.Count; ++X)
                            {
                                Z += Convert.ToInt32(dataGridView1.Rows[X].Cells[3].Value);
                            }
                            textBox13.Text = Z.ToString();

                            //Clear Textbox
                          
                            textBox4.Text = "";
                            textBox5.Text = "";
                            textBox6.Text = "";
                            textBox7.Text = "";
                            textBox8.Text = "";
                            textBox9.Text = "";
                            textBox11.Text = "";
                            label19.Text = "";

                        }
                    }
                    if (found)
                    {
                        dataGridView1.Rows.Add(textBox2.Text, textBox3.Text, 1);

                        //Clear Textbox
                        textBox2.Text = "";
                        textBox3.Text = "";

                    }
                }
                else
                {
                    dataGridView1.Rows.Add(textBox2.Text, textBox3.Text, 1);
                }

                table.Rows.Add(textBox2.Text, textBox3.Text, textBox9.Text, textBox6.Text, textBox7.Text, textBox11.Text);
                dataGridView1.DataSource = table;
                string query3 = string.Format(
               "UPDATE inventorydb.items SET stocks = '" + total + "' Where itemcode = '" + textBox2.Text + "';");
                executeQuery2(query3);

                query4 = string.Format("insert into inventorydb.sales(transactionid, invoiceno, date, oras, itemcode, item, quantity, price, total) values(Default, '" + textBox1.Text + "','" + date + "','" + time + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox9.Text + "','" + textBox7.Text + "','" + textBox11.Text + "');");
                executeQuery2(query4);

                textBox12.Text = dataGridView1.RowCount.ToString();


                //Total Amount

                for (A = 0; A < dataGridView1.Rows.Count; ++A)
                {

                    B += Convert.ToInt32(dataGridView1.Rows[A].Cells[5].Value);

                }

                textBox10.Text = B.ToString();

                //Total Items

                for (C = 0; C < dataGridView1.Rows.Count; ++C)
                {
                    D += Convert.ToInt32(dataGridView1.Rows[C].Cells[2].Value);
                }
                textBox12.Text = D.ToString();


                //total Vat

                for (X = 0; X < dataGridView1.Rows.Count; ++X)
                {
                    Z += Convert.ToInt32(dataGridView1.Rows[X].Cells[3].Value);
                }
                textBox13.Text = Z.ToString();

                //Clear Textbox
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox11.Text = "";
                label19.Text = "";


            }
            catch (Exception) { }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel5.Visible = false;


            int ID = Convert.ToInt32(textBox1.Text);
            ID++;
            textBox1.Text = ID.ToString("D5");
            string query5 = ("UPDATE inventorydb.invoiceno SET invoice1 = '" + textBox1.Text + "' Where invoiceid = 1;");
            executeQuery2(query5);
            dataGridView1.Columns.Clear();
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox11.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox12.Text = "";
            textBox13.Text = "";
            textBox14.Text = "";
            textBox15.Text = "";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel5.Visible = true;
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            try
            {
               
                textBox11.Text = (float.Parse(textBox7.Text) * float.Parse(textBox9.Text)).ToString();
                textBox6.Text = (float.Parse(label18.Text) * float.Parse(textBox9.Text)).ToString();
            }
            catch { }
        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {
            try
            {
                textBox15.Text = (float.Parse(textBox14.Text) - float.Parse(textBox10.Text)).ToString();
            }
            catch { }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to Change the User? ", "", MessageBoxButtons.OK);
            if (dialogResult == DialogResult.OK)
            {
                string time = DateTime.Now.ToString("hh:mm:ss tt");
                string date = DateTime.Now.ToShortDateString();
                string query2 = string.Format("UPDATE inventorydb.loginhistory SET timeout = '" + date + " " + time + "' Where id = '" + label1.Text + "';");
                executeQuery2(query2);
                Loginfrm log = new Loginfrm();
                this.Close();
                log.Show();
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

            DialogResult dialogResult = MessageBox.Show("Are you sure you want to LogOut? ", "", MessageBoxButtons.OK);
            if (dialogResult == DialogResult.OK)
            {
                string time = DateTime.Now.ToString("hh:mm:ss tt");
                string date = DateTime.Now.ToShortDateString();
                string query2 = string.Format("UPDATE inventorydb.loginhistory SET timeout = '" + date + " " + time + "' Where id = '" + label1.Text + "';");
                executeQuery2(query2);
                Application.Exit();

            }
        }
    }
}


    
