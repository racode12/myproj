﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace SalesInventorySystem
{
    public partial class Loginfrm : Form
    {
        public Loginfrm()
        {
            InitializeComponent();
        }
        MySqlConnection con = new MySqlConnection("datasource = localhost;port = 3306 ; username = root ; password = 1234; Database=inventorydb");
        MySqlCommand cmd = new MySqlCommand();

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.ForeColor = Color.CadetBlue;
            panel1.BackColor = Color.CadetBlue;

            textBox2.ForeColor = Color.DarkGray;
            panel2.ForeColor = Color.DarkGray;
            label2.Text = "...";


        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            textBox2.PasswordChar = 'X';
            textBox2.ForeColor = Color.CadetBlue;
            panel2.BackColor = Color.CadetBlue;

            textBox1.ForeColor = Color.DarkGray;
            panel1.BackColor = Color.DarkGray;
            label2.Text = "...";

        }



        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.ForeColor = Color.DarkGray;
            panel1.BackColor = Color.DarkGray;
            textBox2.ForeColor = Color.DarkGray;
            panel2.BackColor = Color.DarkGray;

            con.Open();
            cmd.Connection = con;

            try
            {
                cmd.CommandText = "SELECT count(*) FROM users WHERE username = '" + textBox1.Text + "'COLLATE utf8_bin AND password = '" + textBox2.Text + "' COLLATE utf8_bin";
                int x = int.Parse(cmd.ExecuteScalar().ToString());

                if (textBox1.Text == "" || textBox2.Text == "")
                {
                    label2.ForeColor = Color.Red;
                    label2.Text = "Please enter username and password!";
                    label2.Visible = true;
                }
                else if (x == 1)
                {
                    button1.Enabled = false;
                    textBox1.Enabled = false;
                    textBox2.Enabled = false;
                    label2.Visible = true;
                    label2.ForeColor = Color.Black;
                    label2.Text = "         Logging in...";
                    timer1.Start();


                }
                else
                {
                    button1.Enabled = false;
                    textBox1.Enabled = false;
                    textBox2.Enabled = false;
                    label2.Visible = true;
                    label2.ForeColor = Color.Black;
                    label2.Text = "         Logging in...";
                    timer2.Start();
                    label2.Visible = true;
                }
                con.Close();

            }
            catch (Exception)
            {
                MessageBox.Show("Error connection!");
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            progressBar1.Increment(5);

            if (progressBar1.Value == 70)
            {
                label2.ForeColor = Color.Green;
                label2.Text = "         Login successfully!";
            }
            else if (progressBar1.Value == 100)
            {
                try
                {
                    MySqlCommand cmd = new MySqlCommand("SELECT type FROM users WHERE username = '" + textBox1.Text + "'AND password = '" + textBox2.Text + "'", con);
                    MySqlDataReader reader;

                    con.Open();
                    reader = cmd.ExecuteReader();
                    string type = "";
                    while (reader.Read())
                    {
                        type = reader.GetString(0);
                    }
                    con.Close();


                    if (type == "Admin")
                    { 
                        AdminFrm mainfrm = new AdminFrm();
                        mainfrm.Show();
                        mainfrm.label22.Text = textBox1.Text;
                        timer1.Stop();
                        progressBar1.Value = 0;
                        this.Hide();
                        button1.Enabled = true;
                    }
                    else if (type == "Cashier")
                    {
                        CashierFrm cas = new CashierFrm();
                        cas.Show();
                        cas.label22.Text = textBox1.Text;
                        timer1.Stop();
                        progressBar1.Value = 0;
                        this.Hide();
                        button1.Enabled = true;


                    }
                }

                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            progressBar1.Increment(5);

            if (progressBar1.Value == 100)
            {
                label2.ForeColor = Color.Red;
                label2.Text = "Invalid username/password!";
                timer2.Stop();
                progressBar1.Value = 0;
                button1.Enabled = true;
                textBox1.Enabled = true;
                textBox2.Enabled = true;
                textBox1.Text = "Username";
                textBox2.Text = "Password";
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
         
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_MouseHover_1(object sender, EventArgs e)
        {
            label1.ForeColor = Color.Red;
        }

        private void label1_MouseLeave_1(object sender, EventArgs e)
        {
            label1.ForeColor = Color.White;
        }

        private void label1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_MouseClick(object sender, MouseEventArgs e)
        {
            

        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {

        }
    }
}
